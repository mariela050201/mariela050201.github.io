from geopy.geocoders import Nominatim

import time
import math

geolocator=Nominatim(user_agent='AppMap')
location=geolocator.geocode('Monclova Coahuila')
print(location.address)
print((location.latitude,location.longitude))

