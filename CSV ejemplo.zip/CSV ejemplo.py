"""IMPORT CSV"""
import csv

with open ('EJEMPLO.csv', newline='') as file: #excel guardado en la carpeta de 
    reader= csv.reader(file)                 #python con extension cvs
    for row in reader: 
        print(row)
 