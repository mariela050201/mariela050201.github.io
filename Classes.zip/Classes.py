"""CLASSES""" 
class Lapiz:  #ATRIBUTOS (caracteristicas)
   color = 'Amarillo'   #por default 
   contiene_borrador = False   #Ninguno tiene borrador
   usa_grafito = True  #Todos usan grafito

   #METODOS (acciones)
   #dentro de la clase (tabulacion)
   def DIBUJA(self):        # self = Argumento (auto)
        print('El lapiz esta dibujando.')
   def BORRA(self):
       if self.valido_para_borrar():   #funcion dentro de otra
           print('El lapiz esta borrando.') # si es verdadera
       else:
           print('El lapiz NO puede borrar.')  #si es falsa
                                             #es falsa pq ese atributo es falso
   def valido_para_borrar(self):    
       return self.contiene_borrador   #se regresa al atributo contiene_borrador

#se va a imprimir el else ya que ese atributo es falso 

#Nombre objeto
Lapiz_Comun = Lapiz()  #Nombre clase

     #Nombre objeto.Atributo
print(Lapiz_Comun.color)
print(Lapiz_Comun.contiene_borrador)
print(Lapiz_Comun.usa_grafito)
print('  ')

Lapiz_Comun.DIBUJA()  #Aqui se llama al metodo (accion dibuja)
Lapiz_Comun.BORRA()   #Aqui se llama al metodo (accion borra)

