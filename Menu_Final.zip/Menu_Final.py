OP=0
while OP!= 5 :
       N1= float(input(" DAME UN NUMERO: "))
       N2= float(input(" DAME OTRO NUMERO: "))
       
       print("""
              ¿QUE DESEAS HACER?
              1) SUMAR
              2) RESTAR 
              3) MULTIPLICAR
              4)DIVIDIR
              5) SALIR
              """)
              
       OP= int(input("DAME TU OPCION: "))
        
       if OP==1:
            print(" LA SUMA DE ",N1," + ",N2," ES ",N1+N2 )
       elif OP==2:
            print(" LA RESTA DE ",N1," - ",N2," ES ",N1-N2 )
       elif OP==3:
            print(" LA MULTIPLICACION DE ",N1," * ",N2," ES ",N1*N2 )
       elif OP==4:
            print(" LA DIVISION DE ",N1," / ",N2," ES ",N1/N2 )
       elif OP==5:
            print("FIN")
            break
       else:
            print("INGRESE UNA OPCION CORRECTA. ")
    
    
    
    
    
    
