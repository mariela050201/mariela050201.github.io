"""COLOR CAFE"""
import cv2
import numpy as np

IMAGEN = cv2.imread('CAFE.png')
hsv = cv2.cvtColor(IMAGEN, cv2.COLOR_BGR2HSV)

cafe_bajo = np.array([0,50,30])
cafe_alto = np.array([50,255,255])

mask = cv2.inRange(hsv,cafe_bajo,cafe_alto)

cv2.imshow('Foto Original',IMAGEN)
cv2.imshow('Foto Extraida',mask)

cv2.waitKey(0)
cv2.destroyALLWindows() 

