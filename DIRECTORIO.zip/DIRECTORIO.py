"""DIRECTORIO PERSONAL"""
X=0
AGG=int(input("¿CUANTAS PERSONAS DESEA AGREAGAR?: "))
for X in range(AGG):
    AGG+=1
    NOM=input("INTRODUCE EL NOMBRE: ")
    CEL=int(input("INTRODUCE EL TELEFONO: "))
    TEL=int(input("INTRODUCE EL CELULAR: "))
    DIR=input("INTRODUCE LA CALLE: ")
    EDAD=int(input("INTRODUCE LA EDAD: "))
    print(NOM, ":")
    print(EDAD)
    print(CEL)
    print(TEL)
    print(DIR)
