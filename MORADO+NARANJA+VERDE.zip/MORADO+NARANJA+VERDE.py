"""MORADO+NARANJA+VERDE"""
import cv2
import numpy as np
 
IMAGEN = cv2.imread('RULETA COLORES.jpg')
hsv = cv2.cvtColor(IMAGEN, cv2.COLOR_BGR2HSV)

morado_bajo1 = np.array([132,130,150])          # H  S  V
morado_alto1 = np.array([142,255,255])

naranja_bajo2 = np.array([10,175,150])
naranja_alto2 = np.array([18,255,255])

verde_bajo3 = np.array([40,120,100])
verde_alto3 = np.array([70,255,250])

mask1 = cv2.inRange(hsv,morado_bajo1,morado_alto1)
mask2 = cv2.inRange(hsv,naranja_bajo2,naranja_alto2)
mask3 = cv2.inRange(hsv,verde_bajo3,verde_alto3)


mask=cv2.bitwise_or(mask1,mask2)
maskF=cv2.bitwise_or(mask,mask3)

cv2.imshow('Foto Original',IMAGEN)
cv2.imshow('Foto Extraida',maskF)

cv2.waitKey(0)
cv2.destroyALLWindows() 

