"""COLOR ROJO"""
import cv2
import numpy as np
 
IMAGEN = cv2.imread('ROJO.jpg')
hsv = cv2.cvtColor(IMAGEN, cv2.COLOR_BGR2HSV)

rojo_bajo2 = np.array([0,100,20])
rojo_alto2 = np.array([8,255,255])

rojo_bajo1 = np.array([175,100,20])
rojo_alto1 = np.array([179,255,255])

mask2 = cv2.inRange(hsv,rojo_bajo2,rojo_alto2)
mask1 = cv2.inRange(hsv,rojo_bajo1,rojo_alto1)

mask=cv2.add(mask2,mask1)

cv2.imshow('Foto Original',IMAGEN)
cv2.imshow('Foto Extraida',mask)

cv2.waitKey(0)
cv2.destroyALLWindows() 