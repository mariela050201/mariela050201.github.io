"""AZUL+ROJO+MORADO+VERDE+AMARILLO"""
import cv2
import numpy as np
#***************************************************************
IMAGEN = cv2.imread('RULETA COLORES.jpg')
hsv = cv2.cvtColor(IMAGEN, cv2.COLOR_BGR2HSV)
#****************************************************************
morado_bajo1 = np.array([132,130,150])          # H  S  V
morado_alto1 = np.array([142,255,255])

azul_bajo2 = np.array([100,50,50])
azul_alto2 = np.array([130,255,255])

verde_bajo3 = np.array([40,120,100])
verde_alto3 = np.array([70,255,250])

amarillo_bajo4 = np.array([20,50,50])
amarillo_alto4 = np.array([40,255,255])

rojo_bajo5 = np.array([0,100,20])
rojo_alto5 = np.array([8,255,255])

rojo_bajo6 = np.array([175,100,20])
rojo_alto6 = np.array([179,255,255])
#****************************************************************
mask1 = cv2.inRange(hsv,morado_bajo1,morado_alto1)
mask2 = cv2.inRange(hsv,azul_bajo2,azul_alto2)
mask3 = cv2.inRange(hsv,verde_bajo3,verde_alto3)
mask4 = cv2.inRange(hsv,amarillo_bajo4,amarillo_alto4)
mask5 = cv2.inRange(hsv,rojo_bajo5,rojo_alto5)
mask6 = cv2.inRange(hsv,rojo_bajo6,rojo_alto6)
#****************************************************************
maska=cv2.bitwise_or(mask1,mask2)
maskb=cv2.bitwise_or(maska,mask3)
maskc=cv2.bitwise_or(maskb,mask4)
maskd=cv2.bitwise_or(maskc,mask5)
maske=cv2.bitwise_or(maskd,mask6)   #UNION DE TODAS LAS MASK(COLORES)
#****************************************************************
cv2.imshow('Foto Original',IMAGEN)
cv2.imshow('Foto Extraida',maske)

cv2.waitKey(0)
cv2.destroyALLWindows() 