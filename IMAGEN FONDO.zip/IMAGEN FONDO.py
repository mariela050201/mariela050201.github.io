"""FONDO IMAGEN"""
from tkinter import *
ventana = Tk()
ventana.title('IMAGEN')
ventana.geometry('500x300')
foto=PhotoImage(file='ImagenNueva.png')
fondo = Label(ventana,image=foto).place(x=0,y=0)

ventana.mainloop()
