import matplotlib.pyplot as plt


Est = ['CHIHUAHUA', 'COAHUILA', 'COLIMA', 'DURANGO', ' GUANAJUATO','TOTAL']
DEFUNCIONES = (1377, 1868, 526, 623,2894, 7288)
colores = ('purple', 'red', 'green', 'yellow', 'cyan', 'gray')

plt.barh(range(6),DEFUNCIONES,color=colores)
plt.yticks(range(6), Est, rotation = 60)
plt.title ("DEFUNCION EN ESTADOS POR COVID-19")
plt.xlim(min(DEFUNCIONES)-20,max(DEFUNCIONES)+100)
plt.show()
