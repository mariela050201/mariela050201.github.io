"""EJEMPLO FOR"""
n=[1,2,3,4,5,6,7,8,9,10]
for a in n:     #n es el numero de elementos que contiene,osea 10 
    print (a)   #sin comillas pq es una variable
print("\n\n")
a=0
while a < len(n):    #len(n) es el numero de elementos que contiene n
    print(n[a])      #el elemento numero (n) en la posicion [a], y a empieza en 0
    a+=1             #va sumando de uno en uno para aumentar o subir la posicion
""" va a dar 2 veces seguidas del 1-10 pq es lo mismo"""

    
    
    