"""BASE DE DATOS COVID"""
from tkinter import *
from tkinter.ttk import *
import mysql.connector

mydb = mysql.connector.connect(         #conecta con el servidor
    host = "localhost",
    user = "mariela20",
    password = "LUNA@18beno",
    database = "coronavirus"
)
#Funcion para preguntar el ingreso de datos
def INSERTAR():
    mycursor=mydb.cursor()
    sql="INSERT INTO estados (control,estado) VALUES (%s,%s)"
    NE=input("numero de estado:")
    EST=input("estado:")
    val=(NE,EST)                #introduce un numero de estado y estado
    mycursor.execute(sql,val)

    mydb.commit()
    INSERTAR1()
def INSERTAR1():
    mycursor=mydb.cursor()
    sql="INSERT INTO datos (confirmados,negativos,\
    sospechosos) VALUES (%s,%s,%s)"
    CTL=input("control")
    C=input("confirmados:")
    N=input("negativos:")        #Introduce nuevos datos 
    S=input("sospechosos:")
    val=(CTL,C,N,S)
    mycursor.execute(sql,val)

    mydb.commit()          #Se saca a pantalla que se ha agregado
    print(mycursor.rowcount,"Se ha agregado")
#Datos
def ESTADOS():          #Funcion de todos los estados
    print('Confirmados','Negativos','Sospechosos')
#************************************************************
    if combo.get()=='SAN LUIS POTOSI':
        mycursor=mydb.cursor()

        sql="SELECT \
            datos.Confirmados AS ala, \
            datos.Negativos AS fav, \
            datos.Sospechosos AS ele, \
            prueba.controlE AS olo \
            FROM datos\
            INNER JOIN prueba ON datos.control=prueba.controlE where controlE='1'"

        mycursor.execute(sql)
        myresult=mycursor.fetchall()

        for x in myresult:
            print (x)
#************************************************************
    if combo.get()=='QUINTANAROO':
        mycursor=mydb.cursor()

        sql="SELECT \
            datos.Confirmados AS ala, \
            datos.Negativos AS fav, \
            datos.Sospechosos AS ele, \
            prueba.controlE AS olo \
            FROM datos\
            INNER JOIN prueba ON datos.control=prueba.controlE where controlE='2'"

        mycursor.execute(sql)
        myresult=mycursor.fetchall()

        for x in myresult:
            print (x)
#************************************************************
    if combo.get()=='SINALOA':
        mycursor=mydb.cursor()

        sql="SELECT \
            datos.Confirmados AS ala, \
            datos.Negativos AS fav, \
            datos.Sospechosos AS ele, \
            prueba.controlE AS olo \
            FROM datos\
            INNER JOIN prueba ON datos.control=prueba.controlE where controlE='3'"

        mycursor.execute(sql)
        myresult=mycursor.fetchall()

        for x in myresult:
            print (x)
#************************************************************
    if combo.get()=='SONORA':
        mycursor=mydb.cursor()

        sql="SELECT \
            datos.Confirmados AS ala, \
            datos.Negativos AS fav, \
            datos.Sospechosos AS ele, \
            prueba.controlE AS olo \
            FROM datos\
            INNER JOIN prueba ON datos.control=prueba.controlE where controlE='4'"

        mycursor.execute(sql)
        myresult=mycursor.fetchall()

        for x in myresult:
            print (x)
#************************************************************
    if combo.get()=='TABASCO':
        mycursor=mydb.cursor()

        sql="SELECT \
            datos.Confirmados AS ala, \
            datos.Negativos AS fav, \
            datos.Sospechosos AS ele, \
            prueba.controlE AS olo \
            FROM datos\
            INNER JOIN prueba ON datos.control=prueba.controlE where controlE='5'"

        mycursor.execute(sql)
        myresult=mycursor.fetchall()

        for x in myresult:
            print (x)
#Mostrar la pantalla Principal
windows = Tk()
windows.title('CASOS COVID EN MEXICO')
windows.geometry("390x170")

foto=PhotoImage(file='FONDO.png')
fondo=Label(windows,image=foto).place(x=0, y=0)

texto=StringVar()
texto.set ('Estados: ')

combo = Combobox(windows)
combo.place(x=10,y=20)                                                     
combo['values'] = [
    'QUINTANAROO',
    'SAN LUIS POTOSI',
    'SINALOA',
    'SONORA',
    'TABASCO'
    ]
combo.current(0)

boton=Button(windows,command=guardar,text='AGREGAR')
boton2=Button(windows,command=estados,text='ENTER')
etiqueta=Label(windows,textvariable=texto)
etiqueta.place(x=40,y=400)                                                    
boton.place(x=200,y=130)                                                    
boton2.place(x=100,y=130)                                                    

windows.mainloop()
