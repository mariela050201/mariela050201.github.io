NOM=("Mariela", "Sara", "Adrana", "Sarai")
X=0            
for N in NOM:     #N va a ser cada nombre dependiendo de el incremento
    print(N)      #se va a imprimir cada nombre de uno en uno
    X+=1          # el contador X va ir desde 0 hasta aumentar de uno en uno
                  #que es ir cambiando de nombre
                  #no se puede sumar +1 a N por que es alfanumerico y X es numerico
print("\n\n")
print("Final")
