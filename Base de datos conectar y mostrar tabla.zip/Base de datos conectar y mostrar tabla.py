"""Base de Datos COVID-19"""
import mysql.connector
                             
mydb = mysql.connector.connect(         #conecta con el servidor
    host = "localhost",
    user = "mariela20",
    password = "LUNA@18beno",
    database = "coronavirus"
)
print (mydb)

mycursor = mydb.cursor()
mycursor.execute("SHOW TABLES")  #muestra las tablas que hay en la base de datos
for a in mycursor:                     #covid
    print(a)











