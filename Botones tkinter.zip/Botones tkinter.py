"""BOTONES TKINTER """
from tkinter import *

def call():
    Etiqueta=Label(root,text=' HOLA ')
    Etiqueta.place(x=10, y=140)
    
def llama():
    Etiqueta=Label(root, text='     ')
    Etiqueta=Label(root, text= ' GUARDADO ')
    Etiqueta.place(x=10, y=160)
    
root=Tk()
root.geometry('360x250')

BOTON=Button(root, text=' ENTRAR ', command=call)
BOTON.place(x=10, y=10)

BOTONA=Button(root, text=' GUARDAR ', command=llama)
BOTONA.place(x=10, y=100)

root.mainloop()


