NOM=("MARIELA", "XIEMNA", "SOFIA", "SARA", "ADRIANA", "SARAI")
N=0
while N < len(NOM):
    print(NOM[N])
    N+=1
    
    