# -*- coding: utf-8 -*-
"""
Created on Fri Aug 28 10:19:39 2020

@author: marie
"""

num=10
for i in range(num):
    print(i)
    