"""PIXEL DE UNA FOTO"""
from PIL import Image

foto = Image.open('urticaria.jpg')

pixel = foto.getpixel( (100,50))

print(pixel)
foto.close()
