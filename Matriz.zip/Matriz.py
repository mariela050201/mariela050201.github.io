"""Matriz"""
import numpy as np

a = np.arange(12)
a = a.reshape([3,4]) # CANTIDAD HORIZONTAL,VERTICAL
print(a)  #Matriz completa del 0-11 (12 numeros)
print(a[2,1]) 
print(a[:,3])   # : = toda la fila o columna


#   0 1 2 3  ***** 0
#   4 5 6 7  ***** 1
#   8 9 10 11 **** 3
#   * * *  *
#   * * *  *
#   * * *  *
#   0 1 2  3