"""IMPORT JSON"""
import json
dato={}
dato[' CLIENTES '] = []

dato[' CLIENTES '].append({
    ' PRIMER NOMBRE ': ' JOSE ',
    ' SEGUNDO NOMBRE ': ' LUIS ',
    ' PRIMER APELLIDO ': ' DE LA PAZ ',
    ' SEGUNDO APELLIDO ': ' RAMOS ',
    ' EDAD ': 20 })

dato[' CLIENTES '].append({
    ' PRIMER NOMBRE ': ' FRANSISCO ',
    ' SEGUNDO NOMBRE ': ' ANGEL ',
    ' PRIMER APELLIDO ': ' CHAVEZ ',
    ' SEGUNDO APELLIDO ': ' ROMO ',
    ' EDAD ': 19 })

with open('datos.json','w')as file:
    json.dump(dato,file,indent=2)
    
with open('datos.json')as file:
    dato = json.load(file)
    
    for a in dato[' CLIENTES ']:
        print(' PRIMER NOMBRE ', a [' PRIMER NOMBRE ']) 
        print(' SEGUNDO NOMBRE ', a [' SEGUNDO NOMBRE ']) 
        print(' PRIMER APELLIDO ', a [' PRIMER APELLIDO ']) 
        print(' SEGUNDO APELLIDO ', a [' SEGUNDO APELLIDO ']) 
        print(' EDAD ', a [' EDAD ']) 
        print(' ')


