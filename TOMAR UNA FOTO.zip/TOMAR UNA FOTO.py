"""TOMAR UNA FOTO"""
import cv2
import tkinter
from tkinter import *

ventana=tkinter.Tk()
ventana.title('TOMA UNA FOTO')
ventana.geometry('640x480')

def TOF():    #función 2 regresa a la 1
    TF()

def TF():    #Funcion 1 (TOMAR FOTO)
    camara = cv2.VideoCapture(0)
    LECTURA,frame = camara.read()
    
    if LECTURA == True:
        cv2.imwrite('MARIELA.png',frame)
        print("Foto Exitosa")
           
    else:
        print("ERROR")
        print("La camara no existe o esta desactivada")
        camara.release()
    #insertar la imagen de fondo
    foto=PhotoImage(file='MARIELA.png')
    fondo=Label(ventana,image=foto).place(x=0,y=0)
    #Etiqueta que pregunta    
    texto=StringVar()
    texto.set("¿Deseas tomar otra Foto?: ")
    ETIQUETA=Label(ventana,textvariable=texto)
    ETIQUETA.place(x=50,y=400)
    #Botones de si y de No
    BOTON=Button(ventana,text=' SI ',command=TOF).place(x=75,y=440)
    BOTON=Button(ventana,text=' NO ',command=ventana.destroy).place(x=120,y=440)
    #Que aparezca la foto en la ventana principal    
    ventana.mainloop() 
TF()    

