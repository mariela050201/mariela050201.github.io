"""COVID MEXICO"""
from tkinter import *
from tkinter.ttk import *
import json
root = Tk() 
root.title('COVID-MEXICO')
root.geometry('500x300')

#Insertar Imagen de Fondo************************
foto=PhotoImage(file='ImagenNueva.png')
fondo=Label(root,image=foto).place(x=0, y=0)
#*************************************************
ESTADO1={}
ESTADO1['AGUASCALIENTES']= []
ESTADO1['AGUASCALIENTES'].append({
    ' Estado: ': 'AGUASCALIENTES',
    ' Confirmados: ': 6937,
    ' Sospechosos: ': 577,
    ' Defunciones: ': 589,
    ' Hospitalizados: ':1914, 
    ' Recuperados: ': 4969 })
    #********************************
ESTADO2={}
ESTADO2['BAJA CALIFORNIA']= []
ESTADO2['BAJA CALIFORNIA'].append({
    ' Estado: ': 'BAJA CALIFORNIA',
    ' Confirmados: ': 18921,
    ' Sospechosos: ': 1831,
    ' Defunciones: ': 3510,
    ' Hospitalizados: ': 6555,  
    ' Recuperados: ': 12294})
    #********************************
ESTADO3={}
ESTADO3['BAJA CALIFORNIA SUR']= []
ESTADO3['BAJA CALIFORNIA SUR'].append({
    ' Estado: ': 'BAJA CALIFORNIA SUR',
    ' Confirmados: ': 9904 ,
    ' Sospechosos: ': 407,
    ' Defunciones: ': 448,
    ' Hospitalizados: ': 1181,  
    ' Recuperados: ': 8316 })
    #*********************************
ESTADO4={}
ESTADO4['CAMPECHE']= []
ESTADO4['CAMPECHE'].append({
    ' Estado: ': 'CAMPECHE',
    ' Confirmados: ': 5911,
    ' Sospechosos: ': 148,
    ' Defunciones: ': 808,
    ' Hospitalizados: ': 1856,  
    ' Recuperados: ':  4002})
   #********************************
ESTADO5={}
ESTADO5['CHIAPAS']= []
ESTADO5['CHIAPAS'].append({
    ' Estado: ': 'CHIAPAS',
    ' Confirmados: ': 6501,
    ' Sospechosos: ': 268,
    ' Defunciones: ': 1085,
    ' Hospitalizados: ': 2393, 
    ' Recuperados: ': 4023})
   #********************************
ESTADO6={}
ESTADO6['CHIHUAHUA']= []
ESTADO6['CHIHUAHUA'].append({
    ' Estado: ': 'CHIHUAHUA',
    ' Confirmados: ': 10428,
    ' Sospechosos: ': 3726,
    ' Defunciones: ': 1342,
    ' Hospitalizados: ': 3294, 
    ' Recuperados: ': 7324})
   #********************************
ESTADO7={}
ESTADO7['DISTRITO FEDERAL']= []
ESTADO7['DISTRITO FEDERAL'].append({
    ' Estado: ': 'DISTRITO FEDERAL',
    ' Confirmados: ': 121931,
    ' Sospechosos: ': 19907,
    ' Defunciones: ': 9479,
    ' Hospitalizados: ': 21400, 
    ' Recuperados: ': 98906})
   #********************************
ESTADO8={}
ESTADO8['COAHUILA']= []
ESTADO8['COAHUILA'].append({
    ' Estado: ': 'COAHUILA',
    ' Confirmados: ': 25532,
    ' Sospechosos: ': 3675,
    ' Defunciones: ': 1809,
    ' Hospitalizados: ': 3831, 
    ' Recuperados: ': 21278})
   #********************************
ESTADO9={}
ESTADO9['COLIMA']= []
ESTADO9['COLIMA'].append({
    ' Estado: ': 'COLIMA',
    ' Confirmados: ': 4646,
    ' Sospechosos: ': 220,
    ' Defunciones: ': 514,
    ' Hospitalizados: ': 1350, 
    ' Recuperados: ': 3207})
   #********************************
ESTADO10={}
ESTADO10['DURANGO']= []
ESTADO10['DURANGO'].append({
    ' Estado: ': 'DURANGO',
    ' Confirmados: ': 8455,
    ' Sospechosos: ': 1712,
    ' Defunciones: ': 597,
    ' Hospitalizados: ': 1322, 
    ' Recuperados: ': 6887})   
   #********************************
ESTADO11={}
ESTADO11['GUANAJUATO']= []
ESTADO11['GUANAJUATO'].append({
    ' Estado: ': 'GUANAJUATO',
    ' Confirmados: ': 39841,
    ' Sospechosos: ': 2499,
    ' Defunciones: ': 2831,
    ' Hospitalizados: ': 6271, 
    ' Recuperados: ': 32543})  

#*********************************************************
def ESTADOS():
    if(combo.get())=='AGUASCALIENTES':
        print('COVID EN AGUASCALIENTES')
        print(ESTADO1['AGUASCALIENTES'])
        print('  ')
        
    if(combo.get())=='BAJA CALIFORNIA':
        print('COVID EN BAJA CALIFORNIA')
        print(ESTADO2['BAJA CALIFORNIA'])
        print('  ')
        
    if(combo.get())=='BAJA CALIFORNIA SUR':
        print('COVID EN BAJA CALIFORNIA SUR')
        print(ESTADO3['BAJA CALIFORNIA SUR'])
        print('  ')
        
    if(combo.get())=='CAMPECHE':
        print('COVID EN CAMPECHE')
        print(ESTADO4['CAMPECHE'])
        print('  ')
        
    if(combo.get())=='CHIAPAS':
        print('COVID EN CHIAPAS')
        print(ESTADO5['CHIAPAS'])
        print('  ')
        
    if(combo.get())=='CHIHUAHUA':
        print('COVID EN CHIHUAHUA')
        print(ESTADO6['CHIHUAHUA'])
        print('  ')
        
    if(combo.get())=='DISTRITO FEDERAL':
        print('COVID EN DISTRITO FEDERAL')
        print(ESTADO7['DISTRITO FEDERAL'])
        print('  ')
        
    if(combo.get())=='COAHUILA':
        print('COVID EN COAHUILA')
        print(ESTADO8['COAHUILA'])
        print('  ')
    
    if(combo.get())=='COLIMA':
        print('COVID EN COLIMA')
        print(ESTADO9['COLIMA'])
        print('  ')
        
    if(combo.get())=='DURANGO':
        print('COVID EN DURANGO')
        print(ESTADO10['DURANGO'])
        print('  ')
        
    if(combo.get())=='GUANAJUATO':
        print('COVID EN GUANAJUATO')
        print(ESTADO11['GUANAJUATO'])
        print('  ')
#***********************************************************
def GUARDA():
    if combo.get() =='AGUASCALIENTES':
        with open('ESTADA1.json','w') as file:
             json.dump(ESTADO1['AGUASCALIENTES'],file)
             print('GUARDADO')
   
    if combo.get() =='BAJA CALIFORNIA':
        with open('ESTADA2.json') as file:
             json.dump(ESTADO2['BAJA CALIFORNIA'],file)
             print('GUARDADO')
        
    if combo.get() =='BAJA CALIFORNIA SUR':
        with open('ESTADA3.json','w') as file:
             json.dump(ESTADO3['BAJA CALIFORNIA SUR'],file)
             print('GUARDADO')
    
    if combo.get() =='CAMPECHE':
        with open('ESTADA4.json','w') as file:
             json.dump(ESTADO4['CAMPECHE'],file)
             print('GUARDADO')
             
    if combo.get() =='CHIAPAS':
        with open('ESTADA5.json','w') as file:
             json.dump(ESTADO5['CHIAPAS'],file)
             print('GUARDADO')
             
    if combo.get() =='CHIHUAHUA':
        with open('ESTADA6.json','w') as file:
             json.dump(ESTADO6['CHIHUAHUA'],file)
             print('GUARDADO')
             
    if combo.get() =='DISTRITO FEDERAL':
        with open('ESTADA7.json','w') as file:
             json.dump(ESTADO7['DISTRITO FEDERAL'],file)
             print('GUARDADO')
             
    if combo.get() =='COAHUILA':
        with open('ESTADA8.json','w') as file:
             json.dump(ESTADO8['COAHUILA'],file)
             print('GUARDADO')
    
    if combo.get() =='COLIMA':
        with open('ESTADA9.json','w') as file:
             json.dump(ESTADO9['COLIMA'],file)
             print('GUARDADO')
             
    if combo.get() =='DURANGO':
        with open('ESTADA10.json','w') as file:
             json.dump(ESTADO10['DURANGO'],file)
             print('GUARDADO')
             
    if combo.get() =='GUANAJUATO':
        with open('ESTADA11.json','w') as file:
             json.dump(ESTADO11['GUANAJUATO'],file)
             print('GUARDADO')
#*************************************************************
#Opciones en la ventana Principal
texto=StringVar()
texto.set ('ESTADOS: ')

combo = Combobox(root)
combo.place(x=160,y=40)                                                     
combo['values'] = [
    'AGUASCALIENTES',
    'BAJA CALIFORNIA',
    'BAJA CALIFORNIA SUR',
    'CAMPECHE',
    'CHIAPAS',
    'CHIHUAHUA',
    'DISTRITO FEDERAL',
    'COAHUILA',
    'COLIMA',
    'DURANGO',
    'GUANAJUATO']
combo.current(0)
    
#*************************************
#Botones de Guardar y Enter
BOTON1=Button(root,text='ENTER',command=ESTADOS)
BOTON1.place(x=95,y=100)
BOTON2=Button(root,text='GUARDAR',command=GUARDA)
BOTON2.place(x=250,y=100)

ETIQUETA=Label(root,textvariable=texto)
ETIQUETA.place(x=200,y=20)
#****************************************
root.mainloop()

