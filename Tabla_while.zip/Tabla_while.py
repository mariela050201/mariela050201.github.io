"""While & Else. Mariela De La Paz"""
T=int(input("Que Tabla necesitas?  "))
L=0
print (" La Tabla del", T ,"es: ")
while L < 10:
    L+=1
    print( L," * ", T, " = ",L*T)
    
else:
    print(" FIN ")

