"""Contornos de Imagenes"""
import numpy as np
import cv2

#Foto Original:
ORIGINAL = cv2.imread("dermatitisatopica.jpg")
cv2.imshow("ORIGINAL", ORIGINAL)
#Escala de GRISES:
GRIS  = cv2.cvtColor(ORIGINAL, cv2.COLOR_BGR2GRAY)
#Suavizado Gaussiano:
GAUSS = cv2.GaussianBlur(GRIS, (5,5), 0)
cv2.imshow("Suavizado Gaussaiano", GAUSS)
#Bordes con Canny:
CANNY = cv2.Canny(GAUSS,50,50)
cv2.imshow("CANNY",CANNY)
#Buscar Contornos:
(contornos,_) = cv2.findContours(CANNY.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
#Nmero de monedas por la consola
print(" He encontrado {} objetos".format(len(contornos)))

cv2.drawContours(ORIGINAL,contornos, -1,(0,0,0),2)
cv2.imshow("CONTORNOS", ORIGINAL)

cv2.waitKey(0)

