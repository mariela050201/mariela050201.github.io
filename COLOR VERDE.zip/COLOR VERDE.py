"""COLOR VERDE"""
import cv2
import numpy as np

IMAGEN = cv2.imread('RULETA COLORES.jpg')
hsv = cv2.cvtColor(IMAGEN, cv2.COLOR_BGR2HSV)

verde_bajo = np.array([40,120,100])
verde_alto = np.array([70,255,250])

mask = cv2.inRange(hsv,verde_bajo,verde_alto)

cv2.imshow('Foto Original',IMAGEN)
cv2.imshow('Foto Extraida',mask)

cv2.waitKey(0)
cv2.destroyALLWindows() 




