from io import open
"""ESCRIBIR O MODIFICAR EL ARCHIVO"""
conca= " Mariela De La Paz "
archivo = open ('arch.txt','w')  #Ruta o ubicacion de donde se va a leer
                       # la a+ es para modificar sin que se borre lo anterior
archivo.write (conca)   #la lectura completa 

"""LEER EL ARCHIVO"""
archivo= open ('arch.txt', 'r')   #La r es de read
texto= archivo.read()
archivo.close ()
print (texto) 



