"""RadButton"""
from tkinter import *

from tkinter.ttk import *

windows = Tk() 
windows.title('MENU')

selected= IntVar()

BOT1 = Radiobutton(windows,text=" SUMAR ", value= 1+1, variable=selected)
BOT2 = Radiobutton(windows,text=" RESTAR ", value= 1-1, variable=selected)
BOT3 = Radiobutton(windows,text=" MULTIPLICAR ", value= 1*3, variable=selected)

def seleccion():
    print(selected.get())

BOTON=Button(windows,text=' ENTER ', command= seleccion)
BOT1.grid(column=1, row=1)
BOT2.grid(column=2, row=1)
BOT3.grid(column=3, row=1)
BOTON.grid(column=5, row=1)

windows.mainloop()
